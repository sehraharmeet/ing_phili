# import sqlite3

# conn = sqlite3.connect("client.db")
# cursor = conn.cursor()

# cursor.execute("CREATE TABLE IF NOT EXISTS customers (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)")

# cursor.execute("INSERT INTO customers (name, age) VALUES (?, ?)", ("Reema", 16))
# conn.commit()

# rows = cursor.execute("SELECT * FROM customers").fetchall()
# print(rows)
# conn.close()


import sqlite3

conn = sqlite3.connect("client.db")
cursor = conn.cursor()

cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = cursor.fetchall()

print("Tables:")
for t in tables:
    print(t[0])

