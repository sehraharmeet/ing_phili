import pyautogui
import keyboard
import time



print("Typing started... Press ESC to stop.")


while True:
  text = input("Enter text to type into Notepad: ")


  if keyboard.is_pressed("esc"):
    print("Stopped typing.")
    break


  pyautogui.typewrite(text + "\n", interval=0.05)

  time.sleep(0.1)
