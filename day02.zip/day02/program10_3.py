import requests
import json
import os
import argparse

parser = argparse.ArgumentParser(description="Download JSON posts and save each post as a file.")
parser.add_argument(
    "-ut", "--url","--uri", type=str, required=True,
    help="URL of the JSON data to download"
)
args = parser.parse_args()
json_url = args.url

folder_name = "posts"
os.makedirs(folder_name, exist_ok=True)

response = requests.get(json_url)

if response.status_code == 200:
    data = response.json() 
    report_lines = []

    for post in data:
        post_id = post.get("id")
        filename = os.path.join(folder_name, f"post_{post_id}.txt")
        post_text = json.dumps(post, indent=4, sort_keys=True)

        with open(filename, "w") as f:
            f.write(post_text)

        size = os.path.getsize(filename)
        report_lines.append(f"{filename} - {size} bytes")

    # Write report
    report_file = os.path.join(folder_name, "report.txt")
    with open(report_file, "w") as f:
        f.write("Post Files Report\n")
        f.write("================\n\n")
        for line in report_lines:
            f.write(line + "\n")

    print(f"Saved {len(data)} posts in '{folder_name}' and generated report at '{report_file}'.")
else:
    print(f"Failed to retrieve data from {json_url}. Status code: {response.status_code}")
