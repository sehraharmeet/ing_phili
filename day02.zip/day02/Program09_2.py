from flask import Flask, jsonify, request, Response
import dicttoxml
app = Flask(__name__)

@app.route('/')
def home():
  return "Welcome to the Flask REST API!"

@app.route('/harmeet', methods=['GET'])
def get_data():
  data = {
    'message': 'This is demo response being create by Me.... :-)',
    'status': 'success'
  }
  xml_data = dicttoxml.dicttoxml(data)
  return Response(xml_data, mimetype='application/xml')
  
  #return jsonify(data)
@app.route('/ING', methods=['GET'])
def get_data2():
  data = "Thanks"
  return (data)

app.run(port=5000)


