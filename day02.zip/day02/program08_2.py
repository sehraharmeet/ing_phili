import win32com.client


outlook = win32com.client.Dispatch("Outlook.Application")
namespace = outlook.GetNamespace("MAPI")
inbox = namespace.GetDefaultFolder(6) #its for inbox

target_folder_name = "HarmeetFolder" 
try:
    target_folder = inbox.Folders[target_folder_name]
except Exception:
    print(f"Folder '{target_folder_name}' does not exist under Inbox.")
    exit(1)

messages = inbox.Items
messages.Sort("[ReceivedTime]", True)  

count_moved = 0
for msg in messages:
    try:
        if "harmeet" in msg.Subject.lower(): 
            msg.Move(target_folder)
            count_moved += 1
    except Exception:
        continue

print(f"Finished. Total emails moved: {count_moved}")
