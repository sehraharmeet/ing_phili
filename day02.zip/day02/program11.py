import json

json_data = '{"name": "Harmeet", "age": 25, "skills": ["Python", "Automation"]}'

parsed = json.loads(json_data)
print(parsed)
print(parsed["name"])

with open("output.json", "w") as file:
    json.dump(parsed, file, indent=4)
