import pyautogui
import time
import keyboard


filename = input("Enter filename (without extension): ") + ".txt"


print("Saving file...")


time.sleep(1)


pyautogui.hotkey("alt", "tab")
time.sleep(0.7)


pyautogui.hotkey("ctrl", "s")
time.sleep(1.5)


pyautogui.typewrite(filename, interval=0.05)
time.sleep(1)


pyautogui.press("enter")
time.sleep(1)


if keyboard.is_pressed("tab") is False:
  pyautogui.press("left")  
  pyautogui.press("enter")


print(f"File saved successfully as {filename}")



