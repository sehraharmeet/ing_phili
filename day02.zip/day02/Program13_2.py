import pandas as pd

df = pd.read_excel('data.xlsx', usecols=['Gender', 'Age'])
html_table = df.to_html(index=False)

with open('output.html', 'w') as f:
  f.write('<html><head><title>Excel Data</title></head><body>')
  f.write('<h1>Data from Excel File</h1>')
  f.write(html_table)
  f.write('</body></html>')

print("HTML file created successfully.")
