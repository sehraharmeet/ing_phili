class ExInvalidInputError(Exception):
  def __init__(self, message,username):
    self.message = message
    self.uname=username
    super().__init__(self.message,self.uname)

def check_input(value):
  if not isinstance(value, int):
    raise ExInvalidInputError(f"Expected an integer, got {type(value)} instead.","Line 9 ","ht",)
  return value
 
try:
  print(check_input("india"))
 
except Exception as e:
  print(f"Error: {e.uname}")

