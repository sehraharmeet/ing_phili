import pandas as pd
df = pd.read_excel('data.xlsx', usecols=['Gender', 'Age'])

df['Status2'] = [100, 200, 300, 400, 500]  
df.to_excel('data.xlsx', index=False)

print("content  successfully.")
df = pd.read_excel('data.xlsx', usecols=['Gender', 'Age', 'Status2'])
print(df)

