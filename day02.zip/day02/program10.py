import requests
import json
import os
url = "https://jsonplaceholder.typicode.com/posts"
response = requests.get(url)
if response.status_code == 200:
    data = response.json()  
    os.makedirs("posts", exist_ok=True)
    for post in data:
        post_id = post.get("id")
        filename = f"posts/post_{post_id}.txt"
        post_text = json.dumps(post, indent=4, sort_keys=True)
        with open(filename, "w") as f:
            f.write(post_text)

    print(f"Saved {len(data)} posts in the 'posts' folder.")
else:
    print("Failed to retrieve data.")
