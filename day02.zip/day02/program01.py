import subprocess
import time
import pyautogui

subprocess.Popen("calc.exe")

time.sleep(1.5)


pyautogui.click(300, 300) 

