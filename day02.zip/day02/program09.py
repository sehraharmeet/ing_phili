# import requests
# import json

# url = "https://jsonplaceholder.typicode.com/posts"
# response = requests.get(url)

# print(f"Status Code: {response.status_code}")
# if response.status_code == 200:
#   data = response.json()
#   print("Response JSON:")
#   print(json.dumps(data, indent=4, sort_keys=True))
# else:
#   print("Failed to retrieve data.")


import requests

response = requests.get("http://127.0.0.1:5000/harmeet")
print(response.text)  

response = requests.get("http://127.0.0.1:5000/ING")
print(response.text) 
