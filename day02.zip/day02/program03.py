import pyautogui
import keyboard
import time


print("Interactive typing started...")
print("Type text and press Enter. Press ESC anytime to stop.\n")


while True:
  if keyboard.is_pressed("esc"):
    print("Stopped.")
    break
  text = input("Enter text to type into Notepad: ")
  if keyboard.is_pressed("esc") or text.lower() == "esc":
    print("Stopped.")
    break
  pyautogui.hotkey("alt", "tab")
  time.sleep(0.5)


  pyautogui.typewrite(text + "\n", interval=0.05)
  time.sleep(0.3)


  # Switch back to Terminal
  pyautogui.hotkey("alt", "tab")
  time.sleep(0.5)
