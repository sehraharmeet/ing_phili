import pyautogui
import keyboard
import time
from pywinauto.application import Application

print("Interactive typing started...")
print("Type text and press Enter. Press ESC anytime to stop.\n")

def activate_notepad():
    try:
        app = Application(backend="uia").connect(title_re=".*Notepad.*")
        win = app.top_window()
        win.set_focus()
        time.sleep(0.5)
    except:
        print("Notepad window not found!")

def activate_terminal():
    try:
        app = Application(backend="uia").connect(title_re=".*(Command Prompt|PowerShell).*")
        win = app.top_window()
        win.set_focus()
        time.sleep(0.5)
    except:
        pass

while True:
    if keyboard.is_pressed("esc"):
        print("Stopped.")
        break

    text = input("Enter text to type into Notepad: ")

    if text.lower() == "esc":
        print("Stopped.")
        break

    activate_notepad()

    pyautogui.typewrite(text + "\n", interval=0.05)

    activate_terminal()
