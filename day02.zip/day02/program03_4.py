import pyautogui
import keyboard
import time
import logging
from pywinauto.application import Application

print("Interactive typing started...")
print("Type text and press Enter. Press ESC anytime to stop.\n")

 
logging.basicConfig(
    filename="notepad_errors.log",
    level=logging.ERROR,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

 
class NotepadException(Exception):
    def __init__(self, message):
        super().__init__(message)
        
        logging.error(message)


def activate_notepad():
    try:
        app = Application(backend="uia").connect(title_re=".*Notepad.*")
        win = app.top_window()
        win.set_focus()
        time.sleep(0.5)
    except Exception as e:
        raise NotepadException("Notepad window not found!") from e


def activate_terminal():
    try:
        app = Application(backend="uia").connect(title_re=".*(Command Prompt|PowerShell).*")
        win = app.top_window()
        win.set_focus()
        time.sleep(0.5)
    except:
        pass


while True:
    try:
        if keyboard.is_pressed("esc"):
            print("Stopped.")
            break

        text = input("Enter text to type into Notepad: ")

        if text.lower() == "esc":
            print("Stopped.")
            break

        activate_notepad()  

        pyautogui.typewrite(text + "\n", interval=0.05)

        activate_terminal()

    except NotepadException as ne:
        print(f"[ERROR] {ne}")
        print("→ Logged into notepad_errors.log\n")

    except Exception as ex:
        logging.error(f"Unexpected Error: {ex}")
        print(f"[UNEXPECTED ERROR] {ex}")
