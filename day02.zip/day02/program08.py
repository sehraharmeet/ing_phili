import win32com.client as win32


outlook = win32.Dispatch('outlook.application')

mail = outlook.CreateItem(0) 
mail.To = 'sehraharmeet@gmail.com'
mail.Subject = 'Test Email from Python'
mail.Body = 'Hello,\n\nThis is a test email sent using Python!\n\nBest regards,\nHarmeet'


mail.Send()
print("Email sent successfully!")
