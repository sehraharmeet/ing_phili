try:
    f = open("file.txt")
except FileNotFoundError:
    print("File not found")
else:
    print("File opened successfully")
finally:
    print("Done")

