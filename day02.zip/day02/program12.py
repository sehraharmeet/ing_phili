# import pandas as pd

# #df = pd.read_excel('data.xlsx')
# df = pd.read_excel('data.xlsx',usecols=['Gender', 'Age', 'Status'])
# print(df)


import pandas as pd

df = pd.read_excel("data.xlsx")

cols = df.columns.tolist()
print("Columns found:", cols)

df_selected = df.iloc[:, :3]
print(df_selected)
