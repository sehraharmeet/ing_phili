import win32com.client as win32
import os

outlook = win32.Dispatch('outlook.application')

mail = outlook.CreateItem(0) 
mail.To = 'sehraharmeet@gmail.com'
mail.Subject = 'Test Email from Python'
mail.Body = 'Hello,\n\nThis is a test email sent using Python!\n\nBest regards,\nHarmeet'

attachment_path = r"F:\Trg_ING\day02\posts\report.txt"
if os.path.exists(attachment_path):
    mail.Attachments.Add(attachment_path)
else:
    print(f"Attachment not found: {attachment_path}")

mail.Send()
print("Email sent successfully!")
