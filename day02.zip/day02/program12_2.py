# import pandas as pd

# df = pd.read_excel("data.xlsx",sheet_name="Sheet1")   
# print(df)
# filter_df=df[df["Age"]>30]
# for index, row in filter_df.iterrows():
  
#  print(f"---------------------Row {index}:")
#  print(f"Gender : {row['Gender']}")


import pandas as pd

df = pd.read_excel("data.xlsx",sheet_name="Sheet1")   
#print(df)

df["Age"] = pd.to_numeric(df["Age"])

filter_df=df[(df["Age"]>30) & (df["Gender"] == "Male")]
filter_df["NewAge"]=filter_df["Age"]+50
print(filter_df)
filter_df.to_excel("NewFile.xlsx",index=false)
# for index, row in filter_df.iterrows():
  
#  print(f"---------------------Row {index}:")
#  print(f"Gender : {row['Gender']}")
