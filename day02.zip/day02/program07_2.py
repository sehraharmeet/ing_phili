#pip install mysql.connector

import mysql.connector

try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="harmeet@123",
        database="hellodb"
    )

    cursor = conn.cursor()
    query = "SELECT * FROM emp"
    cursor.execute(query)
    rows = cursor.fetchall()

    for row in rows:
        print(row[1])

except mysql.connector.Error as err:
    print(f"Error: {err}")

finally:
    if cursor:
        cursor.close()
    if conn:
        conn.close()
