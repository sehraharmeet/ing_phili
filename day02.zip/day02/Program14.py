# import pandas as pd
# df = pd.read_excel('data.xlsx', usecols=['Gender', 'Age'])
# df['Status2'] = [100, 200, 300, 400, 500]  
# df.to_excel('data.xlsx', index=False)
# print("content  successfully.")
# df = pd.read_excel('data.xlsx', usecols=['Gender', 'Age', 'Status'])
# print(df)



import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import PatternFill

df = pd.read_excel('data.xlsx', usecols=['Gender', 'Age'])
df['Status2'] = [100, 200, 300, 400, 500]

df.to_excel('data.xlsx', index=False)

wb = load_workbook('data.xlsx')
ws = wb.active

blue_fill = PatternFill(start_color="A5AA27", 
                        end_color="A5AA27",
                        fill_type="solid")

for row in range(2, ws.max_row + 1):   
    ws.cell(row=row, column=3).fill = blue_fill

wb.save('data2.xlsx')

print("Excel updated with background color successfully.")
